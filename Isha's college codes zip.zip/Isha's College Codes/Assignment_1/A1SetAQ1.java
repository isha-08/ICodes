import java.util.ArrayList;
import java.util.Scanner;
public class A1SetAQ1
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		ArrayList Al=new ArrayList();
		System.out.println("Enter the number of cities you want in the arraylist: ");
		int n=sc.nextInt();
		System.out.println("Enter the names of the cities: ");
		for(int i=1; i<=n; i++)
		{
			Al.add(sc.next());
		}
		System.out.println("The Cities entered are: "+Al);
		Al.removeAll(Al);
		System.out.println("The Cities are removed successfullly!"+Al);
	}
}
