import java.util.*;
public class A1SetAQ2
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		LinkedList<String> ll=new LinkedList<String>();
		System.out.println("Enter the number of friends you want in the LinkedList: ");
		int n=sc.nextInt();
		System.out.println("Enter the names of the friends: ");
		for(int i=1; i<=n; i++)
		{
			ll.add(sc.next());
		}
		Iterator<String>itr=ll.iterator();
		System.out.println("The Names Of The Friends Entered Are: "+ll);
	}
}
